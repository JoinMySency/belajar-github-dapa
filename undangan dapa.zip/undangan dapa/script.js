function scrollToNext() {
    document.getElementById('date').scrollIntoView({ 
        behavior: 'smooth' 
    });
}

// Menambahkan smooth scroll untuk semua halaman
document.addEventListener('DOMContentLoaded', function() {
    document.body.style.scrollSnapType = 'y mandatory';
}); 