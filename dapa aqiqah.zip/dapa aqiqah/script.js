document.getElementById('rsvpForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Ambil nilai dari form
    const formData = new FormData(this);
    
    // Di sini Anda bisa menambahkan logika untuk mengirim data ke server
    alert('Terima kasih atas konfirmasi kehadiran Anda!');
    this.reset();
});

// Animasi smooth scroll untuk link anchor
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Tambahkan animasi loading
window.addEventListener('load', function() {
    document.body.classList.add('loaded');
});

// Tambahkan kode untuk mengontrol audio
document.addEventListener('DOMContentLoaded', function() {
    const audio = document.getElementById('bgMusic');
    const audioControl = document.getElementById('audioControl');
    const icon = audioControl.querySelector('i');
    
    let isPlaying = false;

    audioControl.addEventListener('click', function() {
        if (isPlaying) {
            audio.pause();
            icon.classList.remove('fa-pause');
            icon.classList.add('fa-play');
        } else {
            audio.play();
            icon.classList.remove('fa-play');
            icon.classList.add('fa-pause');
        }
        isPlaying = !isPlaying;
    });
}); 